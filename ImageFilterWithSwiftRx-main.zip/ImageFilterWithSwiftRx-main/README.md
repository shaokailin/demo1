# ImageFilterWithSwiftRx
This is a POC to get hands on RxSwift and RxCocoa
