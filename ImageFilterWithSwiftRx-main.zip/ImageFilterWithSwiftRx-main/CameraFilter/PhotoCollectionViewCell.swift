//
//  PhotoCollectionViewCell.swift
//  CameraFilter
//
//  Created by ASHWANI  SHAKYA on 13/12/21.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView:UIImageView!
}

