//
//  FliterService.swift
//  CameraFilter
//
//  Created by ASHWANI  SHAKYA on 14/12/21.
//

import Foundation
import UIKit
import CoreImage
import RxSwift

class FilterService {
    private var context: CIContext
    
    init() {
        self.context = CIContext()
    }
    
   private func applyFilter(to inputImage:UIImage, completion: @escaping((UIImage)-> ())) {
       guard let currentCGImage = inputImage.cgImage else { return }
       let currentCIImage = CIImage(cgImage: currentCGImage)

       let filter = CIFilter(name: "CIColorMonochrome")
       filter?.setValue(currentCIImage, forKey: "inputImage")

       // set a gray value for the tint color
       filter?.setValue(CIColor(red: 0.7, green: 0.7, blue: 0.7), forKey: "inputColor")

       filter?.setValue(1.0, forKey: "inputIntensity")
       guard let outputImage = filter?.outputImage else { return }

       let context = CIContext()

       if let cgimg = context.createCGImage(outputImage, from: outputImage.extent) {
           let processedImage = UIImage(cgImage: cgimg)
           completion(processedImage)
       }
    }
    func applyFilter(to inputImage:UIImage) -> Observable<UIImage> {
        return Observable<UIImage>.create { observer in
            self.applyFilter(to: inputImage) { image in
                observer.onNext(image)
            }
            return Disposables.create()
        }
    }
}
//https://www.cnblogs.com/LisenH/p/7824693.html
extension UIImage {
    func imageWithTintColor(tintColor:UIColor, blendMode:CGBlendMode) -> UIImage? {
            UIGraphicsBeginImageContextWithOptions(self.size, false, 0.0)
            tintColor.setFill()
            let bounds = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height)
            UIRectFill(bounds)
            self.draw(in: bounds, blendMode: blendMode, alpha: 1.0)

//            if blendMode != .destinationIn {
//                self.draw(in: bounds, blendMode: .destinationIn, alpha: 1.0)
//            }
            
            let tintedImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return tintedImage
        }
    func grayImage() -> UIImage?
        {
            UIGraphicsBeginImageContext(self.size)
            let colorSpace = CGColorSpaceCreateDeviceGray()
            let context = CGContext(data: nil , width: Int(self.size.width), height: Int(self.size.height),bitsPerComponent: 8, bytesPerRow: 0, space: colorSpace, bitmapInfo: CGImageAlphaInfo.none.rawValue)
            context?.draw(self.cgImage!, in: CGRect.init(x: 0, y: 0, width: self.size.width, height: self.size.height))
            let cgImage = context!.makeImage()
            let grayImage = UIImage(cgImage: cgImage!, scale: self.scale, orientation: self.imageOrientation)
            return grayImage
            
        }
}
