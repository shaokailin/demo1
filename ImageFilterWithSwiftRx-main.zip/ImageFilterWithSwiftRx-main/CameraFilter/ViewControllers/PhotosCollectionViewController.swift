//
//  PhotosCollectionViewController.swift
//  CameraFilter
//
//  Created by ASHWANI  SHAKYA on 30/11/21.
//

import UIKit
import Photos
import RxSwift

class PhotosCollectionViewController: UICollectionViewController{
    
    private let selectedPhotoSubject = PublishSubject<[UIImage]>()
    var selectedPhoto:Observable<[UIImage]> {
        return selectedPhotoSubject.asObserver()
    }
    
    private var images = [UIImage]()
    override func viewDidLoad() {
        populatePhotos()
    }
    
    private func populatePhotos(){
        PHPhotoLibrary.requestAuthorization { [weak self] status in
            if status == .authorized {
                let assets = PHAsset.fetchAssets(with: PHAssetMediaType.image, options: .none)
                let manager = PHImageManager.default()
                
                assets.enumerateObjects { (object, count, stop) in
                    manager.requestImage(for: object, targetSize: CGSize(width: 100, height: 100), contentMode: .aspectFit, options: nil) { image, _ in
                        FilterService().applyFilter(to: image!).subscribe(onNext: {filteredImage in
                            self?.images.append(filteredImage)
                        })
                        
                    }
                    
                }
                self?.images.reversed()

                DispatchQueue.main.async {
                    self?.collectionView.reloadData()
                }
            }
        }
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.images.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCollectionViewCell", for: indexPath) as? PhotoCollectionViewCell else { fatalError("PhotoCollectionViewCell is not found") }
        cell.imageView.image = self.images[indexPath.row]
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.selectedPhotoSubject.onNext(self.images)
        self.navigationController?.popViewController(animated: true)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("viewDidDisappear")
    }
    
    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        print("dismiss")
    }
}


func instatiateVC(type:UIViewController.Type)->UIViewController{
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    return storyboard.instantiateViewController(withIdentifier: String(describing: type.self))
}
