//
//  UIView+Theme.swift
//  CameraFilter
//
//  Created by linshaokai on 2021/12/22.
//

import Foundation
import UIKit
protocol ViewThemeProtocol {
    
}
extension UIView {
    
}
extension UITableViewCell {
    func c(){
        self.
    }
}
