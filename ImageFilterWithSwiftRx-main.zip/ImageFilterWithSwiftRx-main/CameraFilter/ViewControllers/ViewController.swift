//
//  ViewController.swift
//  CameraFilter
//
//  Created by ASHWANI  SHAKYA on 30/11/21.
//

import UIKit
import RxSwift
import Kingfisher
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1000
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as? TableViewCell
        if cell == nil {
            cell = TableViewCell.init(style: .default, reuseIdentifier: "TableViewCell")
        }
        
        if images.count > 0 {
            let index = indexPath.row % self.images.count
//            FilterService().applyFilter(to: self.images[index]).subscribe(onNext: {filteredImage in
//
//            }).disposed(by: disposeBag)
//            cell?.iconImageView.image = self.images[index].imageWithTintColor(tintColor: .gray, blendMode: .overlay)
            cell?.iconImageView.image = self.images[index].grayImage()
        }
        return cell!;
    }
    lazy var tableView:UITableView = {
        let tableview = UITableView.init(frame: CGRect.zero, style: .plain)
        tableview.rowHeight = 100;
        tableview.dataSource = self
        return tableview
    }()
    let disposeBag = DisposeBag()
    var images:[UIImage] = []
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.title = "Camera Filter"
        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        tableView.theme.backgroundColor = themed { data in
            print(data)
           return data.titleColor
        }
        
    }


    @IBAction func ChoosePhoto(_ sender: Any) {
        MMThemeManager.instanced.changeTheme(theme: .Dark)
        return
        let vc = instatiateVC(type: PhotosCollectionViewController.self) as! PhotosCollectionViewController
        vc.selectedPhoto.subscribe(onNext: { [weak self] data in
            self?.updateUI(with: data)
        }).disposed(by: disposeBag)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private func updateUI(with images: [UIImage]){
        self.images = images;
        self.tableView.reloadData()
    }
    
    @IBAction func applyFilter(_ sender: Any) {

    }
}

