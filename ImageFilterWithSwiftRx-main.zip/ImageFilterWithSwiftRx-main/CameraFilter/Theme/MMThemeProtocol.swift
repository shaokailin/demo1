//
//  MMThemeProtocol.swift
//  CameraFilter
//
//  Created by linshaokai on 2021/12/22.
//

import Foundation
import UIKit
import Kingfisher
protocol ThemeObjectProtocol {
    static func themeProdicer<T>(themeProvider:(_ themeType:ThemeType)->T?)->T?
}
extension ThemeObjectProtocol{
    static func themeProdicer<T>(themeProvider: ((ThemeType) -> T?)) -> T? {
        return themeProvider( MMThemeManager.instanced.type)
    }
}
extension NSObject:ThemeObjectProtocol{}

extension UIImageView {
    @discardableResult
    public func setImage(
        with resource: Resource?,
        placeholder: Placeholder? = nil,
        options: KingfisherOptionsInfo? = nil,
        completionHandler: ((Result<RetrieveImageResult, KingfisherError>) -> Void)? = nil) -> DownloadTask? {
            return self.kf.setImage(with: resource, placeholder: placeholder, options: options) { result in
                if let handler = completionHandler {
                    handler(result)
                }
            }
        }

}
