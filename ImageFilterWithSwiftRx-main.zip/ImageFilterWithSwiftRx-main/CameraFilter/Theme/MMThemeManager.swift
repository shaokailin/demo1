//
//  MMThemeManager.swift
//  CameraFilter
//
//  Created by linshaokai on 2021/12/22.
//

import Foundation
import UIKit

enum ThemeType:ThemeProvider {
    case Nornal
    case Dark
    var associatedObject: ThemeColor {
        
        return ThemeColor()
    }
}
struct ThemeColor {
    
     var titleColor:UIColor? {
        return UIColor.themeProdicer { type in
            return type == .Nornal ? .red:.yellow
        }
    }
    var detailColor:UIColor? {
        return UIColor.themeProdicer { type in
            return .red
        }
    }
    func setImage(name:String) -> UIImage?{
        return UIImage.themeProdicer { type in
            return UIImage.init(named: name)?.imageWithTintColor(tintColor: self.titleColor ?? .clear, blendMode: .overlay)
        }
    }
    func setImage(image:UIImage) -> UIImage? {
        return image.imageWithTintColor(tintColor: self.titleColor ?? .clear, blendMode: .overlay)
    }
}
class MMThemeManager:NSObject {
    static let instanced = MMThemeManager()
    fileprivate let themeService = ThemeType.service(initial: .Nornal);
    public var type:ThemeType = .Nornal
    
    public func changeTheme(theme:ThemeType) {
        guard self.type != theme else {
            return
        }
        self.type = theme
        themeService.switch(theme)
    }
}

func themed<T>(_ mapper: @escaping ((ThemeColor) -> T)) -> ThemeAttribute<T> {
    return MMThemeManager.instanced.themeService.attribute(mapper)
}
